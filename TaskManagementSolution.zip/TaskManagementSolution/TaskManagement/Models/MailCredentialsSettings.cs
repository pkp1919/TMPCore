﻿namespace TaskManagement.Models
{
    public class MailCredentialsSettings
    {
        public string Username { get; set; }
        public string Password { get; set; }
        public string Sender { get; set; }
        public string APIURL { get; set; }
    }
}
