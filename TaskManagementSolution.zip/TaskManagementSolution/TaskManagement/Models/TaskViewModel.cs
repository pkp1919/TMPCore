﻿using Microsoft.AspNetCore.Mvc.Rendering;

namespace TaskManagement.Models
{
    public class TaskViewModel
    {
        public TaskManagementAPI.Models.Task task { get; set; }
        public List<SelectListItem> taskPriorityList { get; set; }
        public List<SelectListItem> taskStatusList { get; set; }
        public List<SelectListItem> projectList { get; set; }
        public List<SelectListItem> userList { get; set; }
    }
}
