﻿namespace TaskManagement.Models
{
    public static class InfrastructureServiceRegistration
    {
        public static IServiceCollection AddInfrastructureServices(this IServiceCollection services, IConfiguration configuration)
        {
            services.Configure<MailCredentialsSettings>(configuration.GetSection("MailCredentialsSettings"));
            return services;
        }
    }
}
