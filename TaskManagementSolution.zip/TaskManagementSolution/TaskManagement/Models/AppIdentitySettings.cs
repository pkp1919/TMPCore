﻿namespace TaskManagement.Models
{
    public class AppIdentitySettings
    {
        //public UserSettings User { get; set; }
        //public PasswordSettings Password { get; set; }
        //public LockoutSettings Lockout { get; set; }
    }
}
