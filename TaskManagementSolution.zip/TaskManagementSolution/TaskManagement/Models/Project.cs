﻿using Microsoft.AspNetCore.Mvc.Rendering;

namespace TaskManagement.Models
{
    public class Project
    {
        public TaskManagementAPI.Models.Project prj { get; set; }
        public List<SelectListItem> projectStatus { get; set; }
        public List<SelectListItem> projectType { get; set; }
        public List<SelectListItem> projectManager { get; set; }
        public IEnumerable<TaskManagementAPI.Models.ProjectStatus> projectStatusList { get; set; }
    }
}
