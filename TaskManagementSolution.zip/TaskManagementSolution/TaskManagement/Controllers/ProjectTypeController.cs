﻿using Microsoft.AspNetCore.Mvc;
using Newtonsoft.Json;
using TaskManagement.Helper;
using TaskManagementAPI.Models;

namespace TaskManagement.Controllers
{
    public class ProjectTypeController : Controller
    {
        private readonly ILogger<ProjectTypeController> _logger;
        private readonly IConfiguration _config;
        private TaskManagementAPIHelper _api;
        // TaskManagementAPIHelper _api = new TaskManagementAPIHelper("");
        public ProjectTypeController(ILogger<ProjectTypeController> logger, IConfiguration config)
        {
            _logger = logger;
            _config = config;
            _api = new TaskManagementAPIHelper(_config.GetValue<string>("MailCredentialsSettings:APIURL"));
        }

        public async Task<IActionResult> Index()
        {
            IEnumerable<ProjectType> lst = null;           
            HttpClient client = _api.Initial();
            HttpResponseMessage res = await client.GetAsync(client.BaseAddress + "api/ProjectType");
            if (res.IsSuccessStatusCode)
            {
                var result = res.Content.ReadAsStringAsync().Result;
                lst = JsonConvert.DeserializeObject<List<ProjectType>>(result);

            }
            else
            {
                return NotFound();
            }
            return View(lst);
        }

        public async Task<IActionResult> Create(int? ID)
        {
            ProjectType lst = new TaskManagementAPI.Models.ProjectType();
            if (ID.HasValue)
            {                
                HttpClient client = _api.Initial();
                HttpResponseMessage res = await client.GetAsync(client.BaseAddress + "api/ProjectType/" + ID.Value);
                if (res.IsSuccessStatusCode)
                {
                    var result = res.Content.ReadAsStringAsync().Result;
                    lst = JsonConvert.DeserializeObject<ProjectType>(result);
                }
            }
            return View(lst);
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public IActionResult Create(ProjectType model)
        {
            try
            {
                if (ModelState.IsValid)
                {                    
                    HttpClient client = _api.Initial();
                    var postTask = client.PostAsJsonAsync<ProjectType>(client.BaseAddress + "api/ProjectType", model);
                    // Add Update Method
                    var result = postTask.Result;
                    if (result.IsSuccessStatusCode)
                    {
                        TempData["success"] = "Project Type Added Successfully";
                        return RedirectToAction("Index");
                    }
                    return NotFound();
                }
                return View(model);

            }
            catch (Exception ex)
            {
                //TempData["success"] = "ProjectStatus Added Successfully";
                return View(model);
            }
        }

        [HttpPost]
        public async Task<JsonResult> CheckCode(int Id, string ProjectStatusCode, int CompareWith)
        {            
            HttpClient client = _api.Initial();
            bool status = false;
            string errorMessage = "";
            HttpResponseMessage res = await client.GetAsync(client.BaseAddress + "api/ProjectStatus/CheckProjectStatusCode/" + Id + "/" + ProjectStatusCode + "/" + CompareWith);
            if (res.IsSuccessStatusCode)
            {
                status = true;
                errorMessage = ProjectStatusCode + " Already Exist";

            }

            return Json(new { status = status, message = errorMessage });
        }

    }
}
