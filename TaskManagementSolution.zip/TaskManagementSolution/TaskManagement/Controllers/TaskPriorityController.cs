﻿using Microsoft.AspNetCore.Mvc;
using Newtonsoft.Json;
using TaskManagement.Helper;
using TaskManagementAPI.Models;


namespace TaskManagement.Controllers
{
    public class TaskPriorityController : Controller
    {
        private readonly ILogger<HomeController> _logger;
        private readonly IConfiguration _config;
        private TaskManagementAPIHelper _api;
        //TaskManagementAPIHelper _api = new TaskManagementAPIHelper();
        public TaskPriorityController(ILogger<HomeController> logger, IConfiguration config)
        {
            _logger = logger;
            _config = config;
            _api = new TaskManagementAPIHelper(_config.GetValue<string>("MailCredentialsSettings:APIURL"));
        }

        public async Task<IActionResult> Index()
        {
            IEnumerable<TaskManagementAPI.Models.TaskPriority> lst = null;            
            HttpClient client = _api.Initial();
            HttpResponseMessage res = await client.GetAsync(client.BaseAddress + "api/TaskPriority");
            if (res.IsSuccessStatusCode)
            {
                var result = res.Content.ReadAsStringAsync().Result;
                lst = JsonConvert.DeserializeObject<List<TaskManagementAPI.Models.TaskPriority>>(result);

            }
            else
            {
                return NotFound();
            }
            return View(lst);
        }

        public async Task<IActionResult> Create(int? ID)
        {
            TaskManagementAPI.Models.TaskPriority lst = new TaskManagementAPI.Models.TaskPriority();
            if (ID.HasValue)
            {                
                HttpClient client = _api.Initial();
                HttpResponseMessage res = await client.GetAsync(client.BaseAddress + "api/TaskPriority/" + ID.Value);
                if (res.IsSuccessStatusCode)
                {
                    var result = res.Content.ReadAsStringAsync().Result;
                    lst = JsonConvert.DeserializeObject<TaskManagementAPI.Models.TaskPriority>(result);
                }
            }
            return View(lst);
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public IActionResult Create(TaskManagementAPI.Models.TaskPriority model)
        {
            try
            {
                if (ModelState.IsValid)
                {                    
                    HttpClient client = _api.Initial();
                    var postTask = client.PostAsJsonAsync<TaskManagementAPI.Models.TaskPriority>(client.BaseAddress + "api/TaskPriority", model);
                    // Add Update Method
                    var result = postTask.Result;
                    if (result.IsSuccessStatusCode)
                    {
                        TempData["success"] = "Task Priority Added Successfully";
                        return RedirectToAction("Index");
                    }
                    return NotFound();
                }
                return View(model);

            }
            catch (Exception ex)
            {
                //TempData["success"] = "ProjectStatus Added Successfully";
                return View(model);
            }
        }

        [HttpPost]
        public async Task<JsonResult> CheckCode(int Id, string TaskStatusCode, int CompareWith)
        {           
            HttpClient client = _api.Initial();
            bool status = false;
            string errorMessage = "";
            HttpResponseMessage res = await client.GetAsync(client.BaseAddress + "api/TaskPriority/CheckTaskStatusCode/" + Id + "/" + TaskStatusCode + "/" + CompareWith);
            if (res.IsSuccessStatusCode)
            {
                status = true;
                errorMessage = TaskStatusCode + " Already Exist";

            }

            return Json(new { status = status, message = errorMessage });
        }

    }
}
