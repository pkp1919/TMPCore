﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Newtonsoft.Json;
using System.Net.Http.Json;
using TaskManagement.Helper;
using RestSharp;
using RestSharp.Authenticators;
using TaskManagementAPI.Models;

namespace TaskManagement.Controllers
{
    public class ProjectController : Controller
    {
        private readonly IConfiguration _config;
        private readonly ILogger<ProjectController> _logger;
        private readonly string _ApiURL;
        private TaskManagementAPIHelper _api;
        private readonly Microsoft.AspNetCore.Hosting.IHostingEnvironment ihostingEnv;
        //TaskManagementAPIHelper _api = new TaskManagementAPIHelper();
        public ProjectController(ILogger<ProjectController> logger, IConfiguration config, Microsoft.AspNetCore.Hosting.IHostingEnvironment _ihostingEnv)
        {
            _config = config;
            _logger = logger;
            _ApiURL = _config.GetValue<string>("MailCredentialsSettings:APIURL");
            _api = new TaskManagementAPIHelper(_ApiURL);
            ihostingEnv = _ihostingEnv;
        }

        public async Task<IActionResult> Index()
        {
            IEnumerable<Project> lst = null;
            var client2 = new RestClient("https://localhost:7192/");
            var request = new RestRequest("api/ProjectAPI/GetDataList", Method.Get);
            lst = client2.Execute<List<Project>>(request).Data;

            //HttpClient client = _api.Initial();
            //HttpResponseMessage res = await client.GetAsync(client.BaseAddress + "api/Project");
            //if (res.IsSuccessStatusCode)
            //{
            //    var result = res.Content.ReadAsStringAsync().Result;
            //    lst = JsonConvert.DeserializeObject<List<Project>>(result);

            //}
            //else
            //{
            //    return NotFound();
            //}
            return View(lst);
        }

        public async Task<IActionResult> Create(int? ID)
        {
            var apiURL = _config.GetValue<string>(
                  "MailCredentialsSettings:APIURL");
            TaskManagementAPIHelper _api = new TaskManagementAPIHelper(apiURL);
            HttpClient client = _api.Initial();
            TaskManagementAPI.ViewModels.ProjectView projectView = new TaskManagementAPI.ViewModels.ProjectView();

            if (ID.HasValue)
            {
                HttpResponseMessage res = await client.GetAsync(client.BaseAddress + "api/ProjectAPI/GetDataByID/" + ID.Value);
                if (res.IsSuccessStatusCode)
                {
                    var result = res.Content.ReadAsStringAsync().Result;
                    projectView = JsonConvert.DeserializeObject<TaskManagementAPI.ViewModels.ProjectView>(result);
                }

                //HttpResponseMessage res = await client.GetAsync(client.BaseAddress + "api/ProjectAPI/" + ID.Value);
                //if (res.IsSuccessStatusCode)
                //{
                //    var result = res.Content.ReadAsStringAsync().Result;
                //    projectView.prj = JsonConvert.DeserializeObject<TaskManagementAPI.Models.Project>(result);
                //}
            }

            //projectView.projectStatus = await GetProjectStatusList();
            //projectView.projectType = await GetProjectTypeList();
            // projectView.projectManager = await GetManagerList();

            return View(projectView);
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Create(TaskManagementAPI.ViewModels.ProjectView model)
        {
            try
            {
               
                string uniqueFileName = "";
                if (model.ProjectImage != null)
                {
                    string uploadFolder = Path.Combine(ihostingEnv.WebRootPath, "ProjectImage");
                    string _fileName = Guid.NewGuid().ToString() + "_" + model.ProjectImage.FileName;
                    string _filePath = Path.Combine(uploadFolder, _fileName);
                    model.ProjectImage.CopyTo(new FileStream(_filePath, FileMode.Create));
                    model.prj.ImagePath = _filePath;
                }

                HttpClient client = _api.Initial();
                var postTask = client.PostAsJsonAsync<Project>(client.BaseAddress + "api/ProjectAPI/AddUpdateData", model.prj);
                // Add Update Method
                var result = postTask.Result;
                if (result.IsSuccessStatusCode)
                {
                    TempData["success"] = "Project Added Successfully";
                    return RedirectToAction("Index");
                }
                return NotFound();


            }
            catch (Exception ex)
            {
                //TempData["success"] = "ProjectStatus Added Successfully";
                return View(model);
            }
        }

        public async Task<List<SelectListItem>> GetProjectStatusList()
        {
            IEnumerable<ProjectStatus> projectStatuslist = null;
            List<SelectListItem> itemList = new List<SelectListItem>();
            HttpClient client = _api.Initial();
            HttpResponseMessage res = await client.GetAsync(client.BaseAddress + "api/ProjectStatus");
            if (res.IsSuccessStatusCode)
            {
                var result = res.Content.ReadAsStringAsync().Result;
                projectStatuslist = JsonConvert.DeserializeObject<List<ProjectStatus>>(result);

                SelectListItem i = new SelectListItem();
                i.Value = "";
                i.Text = "--Select--";
                itemList.Add(i);
                foreach (var item in projectStatuslist)
                {
                    SelectListItem _item = new SelectListItem();
                    _item.Value = item.Id.ToString();
                    _item.Text = item.ProjectStatus1;
                    itemList.Add(_item);
                }
            }

            return itemList;
        }

        public async Task<List<SelectListItem>> GetProjectTypeList()
        {
            IEnumerable<ProjectType> projectTypelist = null;
            List<SelectListItem> itemList = new List<SelectListItem>();
            HttpClient client = _api.Initial();
            HttpResponseMessage res = await client.GetAsync(client.BaseAddress + "api/ProjectType");
            if (res.IsSuccessStatusCode)
            {
                var result = res.Content.ReadAsStringAsync().Result;
                projectTypelist = JsonConvert.DeserializeObject<List<ProjectType>>(result);

                SelectListItem i = new SelectListItem();
                i.Value = "";
                i.Text = "--Select--";
                itemList.Add(i);
                foreach (var item in projectTypelist)
                {
                    SelectListItem _item = new SelectListItem();
                    _item.Value = item.Id.ToString();
                    _item.Text = item.ProjectType1;
                    itemList.Add(_item);
                }
            }

            return itemList;
        }

        public async Task<List<SelectListItem>> GetManagerList()
        {
            IEnumerable<User> Userlist = null;
            List<SelectListItem> itemList = new List<SelectListItem>();
            HttpClient client = _api.Initial();
            HttpResponseMessage res = await client.GetAsync(client.BaseAddress + "api/Login");

            if (res.IsSuccessStatusCode)
            {
                var result = res.Content.ReadAsStringAsync().Result;
                Userlist = JsonConvert.DeserializeObject<List<User>>(result);

                SelectListItem i = new SelectListItem();
                i.Value = "";
                i.Text = "--Select--";
                itemList.Add(i);

                foreach (var item in Userlist)
                {
                    SelectListItem _item = new SelectListItem();
                    _item.Value = item.UserId.ToString();
                    _item.Text = item.UserName;
                    itemList.Add(_item);
                }
            }

            return itemList;
        }
    }
}
