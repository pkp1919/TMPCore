﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Newtonsoft.Json;
using RestSharp;
using System.Net.Http.Json;
using TaskManagement.Helper;
using TaskManagementAPI.Models;

namespace TaskManagement.Controllers
{
    public class TaskController : Controller
    {

        private readonly IConfiguration _config;
        private readonly ILogger<TaskController> _logger;
        private readonly string _ApiURL;
        private TaskManagementAPIHelper _api;
        //TaskManagementAPIHelper _api = new TaskManagementAPIHelper();
        public TaskController(ILogger<TaskController> logger, IConfiguration config)
        {
            _config = config;
            _logger = logger;
            _ApiURL = _config.GetValue<string>("MailCredentialsSettings:APIURL");
            _api = new TaskManagementAPIHelper(_ApiURL);
        }

        public async Task<IActionResult> Index()
        {           
            IEnumerable<TaskManagementAPI.Models.TaskDetailView> lst = null;            
            HttpClient client = _api.Initial();
            HttpResponseMessage res = await client.GetAsync(client.BaseAddress + "api/TaskAPI/GetDataList");

            //var client2 = new RestClient("https://localhost:7192/");
            //var request = new RestRequest("api/TaskAPI/GetDataList", Method.Get);
            //lst = client2.Execute<List<TaskManagementAPI.Models.TaskDetailView>>(request).Data;

            if (res.IsSuccessStatusCode)
            {
                var result = res.Content.ReadAsStringAsync().Result;
                lst = JsonConvert.DeserializeObject<List<TaskManagementAPI.Models.TaskDetailView>>(result);

            }
            else
            {
                return NotFound();
            }
            return View(lst);
           // return View(lst);
        }

        public async Task<IActionResult> Create(int? ID)
        {
          
            var apiURL = _config.GetValue<string>(
                  "MailCredentialsSettings:APIURL");
            TaskManagementAPIHelper _api = new TaskManagementAPIHelper(apiURL);
            HttpClient client = _api.Initial();

            TaskManagementAPI.ViewModels.TaskView taskView = new TaskManagementAPI.ViewModels.TaskView();
            HttpResponseMessage res = await client.GetAsync(client.BaseAddress + "api/TaskAPI/GetDataByID/" + (ID.HasValue ? ID.Value : 0));

            if (res.IsSuccessStatusCode)
            {
                var result = res.Content.ReadAsStringAsync().Result;
                taskView = JsonConvert.DeserializeObject<TaskManagementAPI.ViewModels.TaskView>(result);
            }

            return View(taskView);
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Create(TaskManagementAPI.ViewModels.TaskView model)
        {          

            try
            {
                string UserName = HttpContext.Session.GetString(HomeController.SessionUserName);
                string _UserID = HttpContext.Session.GetString(HomeController.SessionUserID);
                Guid UserID = new Guid(_UserID);
                model.task.CreatedBy = model.task.TaskCreatedBy = model.task.ModifyBy = UserID;
                model.task.CreatedDate = DateTime.Now;
                model.task.TaskStartDate = DateTime.Now;
                model.task.TaskEndDate = DateTime.Now;

                HttpClient client = _api.Initial();
                // var postTask = client.PostAsJsonAsync<TaskManagementAPI.Models.Task>(client.BaseAddress + "api/Task", model.task);
                var postTask = client.PostAsJsonAsync<TaskManagementAPI.Models.Task>(client.BaseAddress + "api/TaskAPI/AddUpdateData", model.task);

                // Add Update Method

                var result = postTask.Result;
                if (result.IsSuccessStatusCode)
                {
                    TempData["success"] = "Task Added Successfully";
                    return RedirectToAction("Index");
                }
                return NotFound();
            }
            catch (Exception ex)
            {
                return View(model);
            }
            //}
            //return View(model2);
        }

        public async Task<List<SelectListItem>> GetProjectStatusList()
        {
            IEnumerable<ProjectStatus> projectStatuslist = null;
            List<SelectListItem> itemList = new List<SelectListItem>();
            HttpClient client = _api.Initial();
            HttpResponseMessage res = await client.GetAsync(client.BaseAddress + "api/ProjectStatus");
            if (res.IsSuccessStatusCode)
            {
                var result = res.Content.ReadAsStringAsync().Result;
                projectStatuslist = JsonConvert.DeserializeObject<List<ProjectStatus>>(result);

                SelectListItem i = new SelectListItem();
                i.Value = "";
                i.Text = "--Select--";
                itemList.Add(i);
                foreach (var item in projectStatuslist)
                {
                    SelectListItem _item = new SelectListItem();
                    _item.Value = item.Id.ToString();
                    _item.Text = item.ProjectStatus1;
                    itemList.Add(_item);
                }
            }

            return itemList;
        }

        public async Task<List<SelectListItem>> GetProjectTypeList()
        {
            IEnumerable<ProjectType> projectTypelist = null;
            List<SelectListItem> itemList = new List<SelectListItem>();
            HttpClient client = _api.Initial();
            HttpResponseMessage res = await client.GetAsync(client.BaseAddress + "api/ProjectType");
            if (res.IsSuccessStatusCode)
            {
                var result = res.Content.ReadAsStringAsync().Result;
                projectTypelist = JsonConvert.DeserializeObject<List<ProjectType>>(result);

                SelectListItem i = new SelectListItem();
                i.Value = "";
                i.Text = "--Select--";
                itemList.Add(i);
                foreach (var item in projectTypelist)
                {
                    SelectListItem _item = new SelectListItem();
                    _item.Value = item.Id.ToString();
                    _item.Text = item.ProjectType1;
                    itemList.Add(_item);
                }
            }

            return itemList;
        }

        public async Task<List<SelectListItem>> GetManagerList()
        {
            IEnumerable<User> Userlist = null;
            List<SelectListItem> itemList = new List<SelectListItem>();
            HttpClient client = _api.Initial();
            HttpResponseMessage res = await client.GetAsync(client.BaseAddress + "api/Login");

            if (res.IsSuccessStatusCode)
            {
                var result = res.Content.ReadAsStringAsync().Result;
                Userlist = JsonConvert.DeserializeObject<List<User>>(result);

                SelectListItem i = new SelectListItem();
                i.Value = "";
                i.Text = "--Select--";
                itemList.Add(i);

                foreach (var item in Userlist)
                {
                    SelectListItem _item = new SelectListItem();
                    _item.Value = item.UserId.ToString();
                    _item.Text = item.UserName;
                    itemList.Add(_item);
                }
            }

            return itemList;
        }
    }
}
