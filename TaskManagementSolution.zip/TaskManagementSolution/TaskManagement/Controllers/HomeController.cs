﻿using Microsoft.AspNetCore.Mvc;
using Newtonsoft.Json;
using System.Collections.Generic;
using System.Diagnostics;
using TaskManagement.Models;
using TaskManagement.Helper;
using TaskManagementAPI;
using TaskManagementAPI.Models;

namespace TaskManagement.Controllers
{
    public class HomeController : Controller
    {
        private readonly ILogger<HomeController> _logger;
        // TaskManagementAPIHelper _api = new TaskManagementAPIHelper();
        private readonly IConfiguration _config;
        private TaskManagementAPIHelper _api;
        public const string SessionUserName = "_UserName";
        public const string SessionUserID = "_UserID";
        public HomeController(ILogger<HomeController> logger, IConfiguration config)
        {
            _config = config;
            _logger = logger;           
            _api = new TaskManagementAPIHelper(_config.GetValue<string>("MailCredentialsSettings:APIURL"));
        }

        public async Task<IActionResult> Login()
        {           
            HttpClient client = _api.Initial();
            List<User> lst = new List<User>();
            HttpResponseMessage res = await client.GetAsync(client.BaseAddress + "api/Login");
            if (res.IsSuccessStatusCode)
            {
                var result = res.Content.ReadAsStringAsync().Result;
                lst = JsonConvert.DeserializeObject<List<User>>(result);

            }
            return View();
        }

        public async Task<IActionResult> Index()
        {            
            HttpClient client = _api.Initial();
            List<User> lst = new List<User>();
            HttpResponseMessage res = await client.GetAsync(client.BaseAddress + "api/Login");
            if (res.IsSuccessStatusCode)
            {
                var result = res.Content.ReadAsStringAsync().Result;
                lst = JsonConvert.DeserializeObject<List<User>>(result);

            }
            return View();
        }

        [HttpPost]
        public async Task<IActionResult> Index(Login model)
        {
            HttpClient client = _api.Initial();
            //https://localhost:7192/api/Login/admin/pass%23123
            HttpResponseMessage res = await client.GetAsync(client.BaseAddress + "api/Login/" + model.UserName + "/" + model.Password);
            TaskManagementAPI.Models.User user = new TaskManagementAPI.Models.User();
            if (res.IsSuccessStatusCode)
            {
                var result = res.Content.ReadAsStringAsync().Result;
                user = JsonConvert.DeserializeObject<TaskManagementAPI.Models.User>(result);
                HttpContext.Session.SetString(SessionUserName, user.FirstName);
                HttpContext.Session.SetString(SessionUserID, user.UserId.ToString());
                return RedirectToAction("Index", "Task");

            }

           
            return RedirectToAction("Index", "Task");
            //return View();
        }

        public IActionResult Privacy()
        {
            return View();
        }

        [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
        public IActionResult Error()
        {
            return View(new ErrorViewModel { RequestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier });
        }
    }
}