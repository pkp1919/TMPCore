﻿using Microsoft.AspNetCore.Mvc;
using Newtonsoft.Json;
using TaskManagement.Helper;
using TaskManagementAPI.Models;

namespace TaskManagement.Controllers
{
    public class ProjectStatusController : Controller
    {
        private readonly ILogger<ProjectStatusController> _logger;
        // TaskManagementAPIHelper _api = new TaskManagementAPIHelper();
        private readonly IConfiguration _config;
        private TaskManagementAPIHelper _api;
        public ProjectStatusController(ILogger<ProjectStatusController> logger, IConfiguration config)
        {
            _logger = logger;
            _config = config;
            _api = new TaskManagementAPIHelper(_config.GetValue<string>("MailCredentialsSettings:APIURL"));
        }

        public async Task<IActionResult> Index()
        {
            IEnumerable<ProjectStatus> lst = null;            
            HttpClient client = _api.Initial();
            HttpResponseMessage res = await client.GetAsync(client.BaseAddress + "api/ProjectStatus");
            if (res.IsSuccessStatusCode)
            {
                var result = res.Content.ReadAsStringAsync().Result;
                lst = JsonConvert.DeserializeObject<List<ProjectStatus>>(result);

            }
            else
            {
                return NotFound();
            }
            return View(lst);
        }

        public async Task<IActionResult> Create(int? ID)
        {
            ProjectStatus lst = new TaskManagementAPI.Models.ProjectStatus();
            if (ID.HasValue)
            {                
                HttpClient client = _api.Initial();
                HttpResponseMessage res = await client.GetAsync(client.BaseAddress + "api/ProjectStatus/" + ID.Value);
                if (res.IsSuccessStatusCode)
                {
                    var result = res.Content.ReadAsStringAsync().Result;
                    lst = JsonConvert.DeserializeObject<ProjectStatus>(result);
                }
            }
            return View(lst);
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public IActionResult Create(ProjectStatus model)
        {
            try
            {
                if (ModelState.IsValid)
                {                   
                    HttpClient client = _api.Initial();
                    var postTask = client.PostAsJsonAsync<ProjectStatus>(client.BaseAddress + "api/ProjectStatus", model);
                    // Add Update Method
                    var result = postTask.Result;
                    if (result.IsSuccessStatusCode)
                    {
                        TempData["success"] = "Project Status Added Successfully";
                        return RedirectToAction("Index");
                    }
                    return NotFound();
                }
                return View(model);

            }
            catch (Exception ex)
            {
                //TempData["success"] = "ProjectStatus Added Successfully";
                return View(model);
            }
        }

        [HttpPost]
        public async Task<JsonResult> CheckCode(int Id, string ProjectStatusCode, int CompareWith)
        {            
            HttpClient client = _api.Initial();
            bool status = false;
            string errorMessage = "";
            HttpResponseMessage res = await client.GetAsync(client.BaseAddress + "api/ProjectStatus/CheckProjectStatusCode/" + Id + "/" + ProjectStatusCode + "/" + CompareWith);
            if (res.IsSuccessStatusCode)
            {
                status = true;
                errorMessage = ProjectStatusCode + " Already Exist";
            }
            return Json(new { status = status, message = errorMessage });
        }


    }
}
