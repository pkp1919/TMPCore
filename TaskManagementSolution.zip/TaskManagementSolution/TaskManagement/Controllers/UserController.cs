﻿using Microsoft.AspNetCore.Mvc;
using Newtonsoft.Json;
using System.Drawing;
//using System.Web.Mvc;
using TaskManagement.Helper;
using TaskManagementAPI;
using TaskManagementAPI.Models;

namespace TaskManagement.Controllers
{
    public class UserController : Controller
    {
        private readonly ILogger<HomeController> _logger;
        private readonly IConfiguration _config;
        private TaskManagementAPIHelper _api;
        //TaskManagementAPIHelper _api = new TaskManagementAPIHelper();
        public UserController(ILogger<HomeController> logger, IConfiguration config)
        {
            _logger = logger;
            _config = config;
            _api = new TaskManagementAPIHelper(_config.GetValue<string>("MailCredentialsSettings:APIURL"));
        }
        public async Task<IActionResult> Index()
        {
            IEnumerable<User> lst = null;            
            HttpClient client = _api.Initial();
            HttpResponseMessage res = await client.GetAsync(client.BaseAddress + "api/Login");
            if (res.IsSuccessStatusCode)
            {
                var result = res.Content.ReadAsStringAsync().Result;
                lst = JsonConvert.DeserializeObject<List<User>>(result);

            }
            return View(lst);
        }

        public async Task<IActionResult> Create(Guid? ID)
        {
            User lst = new TaskManagementAPI.Models.User();
            // lst.modeType = 1;
            if (ID.HasValue)
            {
                lst = null;                
                HttpClient client = _api.Initial();
                //https://localhost:7164/api/Category/4
                HttpResponseMessage res = await client.GetAsync(client.BaseAddress + "api/Login/" + ID.Value);
                if (res.IsSuccessStatusCode)
                {
                    var result = res.Content.ReadAsStringAsync().Result;
                    lst = JsonConvert.DeserializeObject<User>(result);
                    //lst.modeType = 2;
                }
            }
            return View(lst);
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public IActionResult Create(User model)
        {
            try
            {
                //if (model.FirstName == "Pradip k")
                //{
                //    ModelState.AddModelError("FirstName", "First Name Allready Exist");
                //}
                //else
                //{
                if (ModelState.IsValid)
                {                    
                    HttpClient client = _api.Initial();
                    if (model.UserId == new Guid("00000000-0000-0000-0000-000000000000"))
                    {
                        var postTask = client.PostAsJsonAsync<User>(client.BaseAddress + "api/Login", model);
                        //putTask.Wait();
                        var result = postTask.Result;
                        TempData["success"] = "User Added Successfully";
                        return RedirectToAction("Index");
                    }
                    else
                    {
                        var putTask = client.PutAsJsonAsync<User>(client.BaseAddress + "api/Login", model);
                        //putTask.Wait();
                        var result = putTask.Result;
                        TempData["success"] = "User Update Successfully";
                        return RedirectToAction("Index");

                    }
                }
                //}
                return View(model);

            }
            catch (Exception ex)
            {
                return View(model);
            }
        }

        [HttpPost]
        public async Task<JsonResult> CheckUserName(Guid UserID, string UserName)
        {            
            HttpClient client = _api.Initial();
            bool status = false;
            string errorMessage = "";
            HttpResponseMessage res = await client.GetAsync(client.BaseAddress + "api/Login/CheckUserName/" + UserName + "/" + UserID);
            if (res.IsSuccessStatusCode)
            {
                status = true;
                errorMessage = UserName + " Already Exist";

            }
            return Json(new { status = status, message = errorMessage });
        }

        [HttpPost]
        public IActionResult Details(string customerId)
        {


            return PartialView("Details", new TaskManagementAPI.Models.User());
        }

        [HttpPost]
        public async Task<JsonResult> IsAlreadySigned(string UserName, Guid UserID)
        {
            bool status = true;
            return Json(status);

        }

        //public  IActionResult Add()
        //{
        //    User lst = new TaskManagementAPI.Models.User();
        //    return View(lst);
        //}

    }
}
