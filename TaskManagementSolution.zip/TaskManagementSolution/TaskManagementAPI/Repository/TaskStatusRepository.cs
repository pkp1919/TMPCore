﻿using Microsoft.EntityFrameworkCore;
using TaskManagementAPI.Models;
//using System;
//using System.Collections.Generic;
//using System.Threading.Tasks;

namespace TaskManagementAPI.Repository
{
    public interface ITaskStatusRepository
    {
        Task<IEnumerable<Models.TaskStatus>> GetTaskStatus();
        Task<Models.TaskStatus> GetTaskStatusByID(int ID);
        Task<Models.TaskStatus> InsertTaskStatus(Models.TaskStatus obj);
        Task<Models.TaskStatus> UpdateTaskStatus(Models.TaskStatus obj);
        bool DeleteTaskStatus(int ID);
    }
    public class TaskStatusRepository : ITaskStatusRepository
    {
        private readonly TaskManagementContext _appDBContext;

        public TaskStatusRepository(TaskManagementContext context)
        {
            _appDBContext = context ?? throw new ArgumentNullException(nameof(context));
        }

        public bool DeleteTaskStatus(int ID)
        {
            bool result = false;
            var department = _appDBContext.TaskStatuses.Find(ID);
            if (department != null)
            {
                _appDBContext.Entry(department).State = EntityState.Deleted;
                _appDBContext.SaveChanges();
                result = true;
            }
            else
            {
                result = false;
            }
            return result;
        }

        public async Task<IEnumerable<Models.TaskStatus>> GetTaskStatus()
        {
            return await _appDBContext.TaskStatuses.ToListAsync();
        }

        public async Task<Models.TaskStatus> GetTaskStatusByID(int ID)
        {
            return await _appDBContext.TaskStatuses.FindAsync(ID);
        }

        public async Task<Models.TaskStatus> InsertTaskStatus(Models.TaskStatus model)
        {


            if (model.Id > 0)
            {
                model.ModifyDate = DateTime.Now;
                _appDBContext.Entry(model).State = EntityState.Modified;
                await _appDBContext.SaveChangesAsync();
            }
            else
            {
                model.Id = 0;
                model.CreatedDate = model.ModifyDate = DateTime.Now;
                await _appDBContext.TaskStatuses.AddAsync(model);
                await _appDBContext.SaveChangesAsync();
            }


            //_appDBContext.TaskStatuses.Add(obj);
            //await _appDBContext.SaveChangesAsync();
            return model;
        }

        public async Task<Models.TaskStatus> UpdateTaskStatus(Models.TaskStatus obj)
        {
            _appDBContext.Entry(obj).State = EntityState.Modified;
            await _appDBContext.SaveChangesAsync();
            return obj;
        }
    }
}
