﻿using Microsoft.EntityFrameworkCore;
using TaskManagementAPI.Models;
using System;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace TaskManagementAPI.Repository
{
    public interface ITaskRepository
    {
        Task<IEnumerable<TaskManagementAPI.Models.TaskDetailView>> GetDataList();
        Task<ViewModels.TaskView> GetDataByID(int ID);
        Task<Models.Task> InsertData(Models.Task obj);
        Task<Models.Task> UpdateData(Models.Task obj);
        bool DeleteData(int ID);
    }
    public class TaskRepository : ITaskRepository
    {
        private readonly TaskManagementContext _appDBContext;

        public TaskRepository(TaskManagementContext context)
        {
            _appDBContext = context ?? throw new ArgumentNullException(nameof(context));
        }
        public bool DeleteData(int ID)
        {
            bool result = false;
            var data = _appDBContext.Tasks.Find(ID);
            if (data != null)
            {
                _appDBContext.Entry(data).State = EntityState.Deleted;
                _appDBContext.SaveChanges();
                result = true;
            }
            else
            {
                result = false;
            }
            return result;
        }

        public async Task<ViewModels.TaskView> GetDataByID(int ID)
        {
            TaskManagementAPI.ViewModels.TaskView pjs = new TaskManagementAPI.ViewModels.TaskView();
            pjs = new TaskManagementAPI.ViewModels.TaskView().InitializeDefaultData(_appDBContext);
            pjs.task = await _appDBContext.Tasks.Where(i => i.Id == ID).FirstOrDefaultAsync();
            return pjs;
          //  return await _appDBContext.Tasks.FindAsync(ID);
        }

        public async Task<IEnumerable<TaskManagementAPI.Models.TaskDetailView>> GetDataList()
        {
            var lst = await _appDBContext.TaskDetailViews.ToListAsync();
            return lst;
        }

        public async Task<Models.Task> InsertData(Models.Task model)
        {
            if (model.Id > 0)
            {
                model.ModifyDate = DateTime.Now;
                _appDBContext.Entry(model).State = EntityState.Modified;
                await _appDBContext.SaveChangesAsync();
            }
            else
            {
                model.Id = 0;
                model.CreatedDate = model.ModifyDate = DateTime.Now;
                await _appDBContext.Tasks.AddAsync(model);
                await _appDBContext.SaveChangesAsync();
            }            
            return model;
        }

        public async Task<Models.Task> UpdateData(Models.Task model)
        {
            _appDBContext.Entry(model).State = EntityState.Modified;
            await _appDBContext.SaveChangesAsync();
            return model;
        }
    }
}
