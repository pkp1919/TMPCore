﻿using Microsoft.EntityFrameworkCore;
using TaskManagementAPI.Models;

namespace TaskManagementAPI.Repository
{
    public interface IProjectRepository
    {
        Task<IEnumerable<TaskManagementAPI.Models.Project>> GetDataList();
        Task<ViewModels.ProjectView> GetDataByID(int ID);
        Task<Models.Project> InsertData(Models.Project obj);
        Task<Models.Project> UpdateData(Models.Project obj);
        bool DeleteData(int ID);
    }
    public class ProjectRepository : IProjectRepository
    {
        private readonly TaskManagementContext _appDBContext;

        public ProjectRepository(TaskManagementContext context)
        {
            _appDBContext = context ?? throw new ArgumentNullException(nameof(context));
        }
        public bool DeleteData(int ID)
        {
            bool result = false;
            var data = _appDBContext.Tasks.Find(ID);
            if (data != null)
            {
                _appDBContext.Entry(data).State = EntityState.Deleted;
                _appDBContext.SaveChanges();
                result = true;
            }
            else
            {
                result = false;
            }
            return result;
        }

        public async Task<ViewModels.ProjectView> GetDataByID(int ID)
        {
            TaskManagementAPI.ViewModels.ProjectView pjs = new TaskManagementAPI.ViewModels.ProjectView();
            pjs = new TaskManagementAPI.ViewModels.ProjectView().InitializeDefaultData(_appDBContext);
            pjs.prj = await _appDBContext.Projects.Where(i => i.Id == ID).FirstOrDefaultAsync();
            return pjs;            
        }

        public async Task<IEnumerable<TaskManagementAPI.Models.Project>> GetDataList()
        {
            var lst = await _appDBContext.Projects.ToListAsync();
            return lst;
        }

        public async Task<Models.Project> InsertData(Models.Project model)
        {
            if (model.Id > 0)
            {
                model.ModifyDate = DateTime.Now;
                _appDBContext.Entry(model).State = EntityState.Modified;
                await _appDBContext.SaveChangesAsync();
            }
            else
            {
                model.Id = 0;
                model.CreatedDate = model.ModifyDate = DateTime.Now;
                await _appDBContext.Projects.AddAsync(model);
                await _appDBContext.SaveChangesAsync();
            }
            return model;
        }

        public async Task<Models.Project> UpdateData(Models.Project model)
        {
            _appDBContext.Entry(model).State = EntityState.Modified;
            await _appDBContext.SaveChangesAsync();
            return model;
        }
    }
}
