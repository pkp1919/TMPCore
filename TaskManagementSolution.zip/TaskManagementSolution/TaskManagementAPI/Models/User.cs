﻿using System;
using System.Collections.Generic;

namespace TaskManagementAPI.Models;

public partial class User
{
    public Guid UserId { get; set; }

    public string? FirstName { get; set; }

    public string? LastName { get; set; }

    public string? Email { get; set; }

    public string? UserName { get; set; }

    public string? Password { get; set; }

    public bool IsAdmin { get; set; }

    public string? ImagePath { get; set; }

    public DateTime? CreatedDate { get; set; }

    public DateTime? ModifyDate { get; set; }

    public virtual ICollection<ProjectTeam> ProjectTeams { get; } = new List<ProjectTeam>();

    public virtual ICollection<Project> Projects { get; } = new List<Project>();

    public virtual ICollection<ToDoList> ToDoLists { get; } = new List<ToDoList>();
}
