﻿using System;
using System.Collections.Generic;

namespace TaskManagementAPI.Models;

public partial class TaskDetailView
{
    public int Id { get; set; }

    public int ProjectId { get; set; }

    public string? TaskSubject { get; set; }

    public Guid? TaskCreatedBy { get; set; }

    public Guid TaskAssignedfrom { get; set; }

    public Guid TaskAssignedTo { get; set; }

    public string TaskDescription { get; set; } = null!;

    public DateTime? TaskStartDate { get; set; }

    public DateTime? TaskEndDate { get; set; }

    public int TaskPriority { get; set; }

    public int TaskStatus { get; set; }

    public int TaskParentId { get; set; }

    public bool IsActive { get; set; }

    public bool IsDelete { get; set; }

    public Guid? CreatedBy { get; set; }

    public Guid? ModifyBy { get; set; }

    public DateTime? CreatedDate { get; set; }

    public DateTime? ModifyDate { get; set; }

    public string? ProjectName { get; set; }

    public string TaskPriorityName { get; set; } = null!;

    public string TaskStatusName { get; set; } = null!;

    public string? AssignTo { get; set; }
}
