﻿using System;
using System.Collections.Generic;
using Microsoft.EntityFrameworkCore;

namespace TaskManagementAPI.Models;

public partial class TaskManagementContext : DbContext
{
    public TaskManagementContext()
    {
    }

    public TaskManagementContext(DbContextOptions<TaskManagementContext> options)
        : base(options)
    {
    }

    public virtual DbSet<Project> Projects { get; set; }

    public virtual DbSet<ProjectStatus> ProjectStatuses { get; set; }

    public virtual DbSet<ProjectTeam> ProjectTeams { get; set; }

    public virtual DbSet<ProjectType> ProjectTypes { get; set; }

    public virtual DbSet<Task> Tasks { get; set; }

    public virtual DbSet<TaskDetailView> TaskDetailViews { get; set; }

    public virtual DbSet<TaskPriority> TaskPriorities { get; set; }

    public virtual DbSet<TaskStatus> TaskStatuses { get; set; }

    public virtual DbSet<ToDoList> ToDoLists { get; set; }

    public virtual DbSet<User> Users { get; set; }

    protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
#warning To protect potentially sensitive information in your connection string, you should move it out of source code. You can avoid scaffolding the connection string by using the Name= syntax to read it from configuration - see https://go.microsoft.com/fwlink/?linkid=2131148. For more guidance on storing connection strings, see http://go.microsoft.com/fwlink/?LinkId=723263.
        => optionsBuilder.UseSqlServer("Data Source=115.246.25.82;Initial Catalog=TaskManagement;Persist Security Info=True;User ID=sa;Password=Sql@2017!123#;\nConnect Timeout=30;Encrypt=False;TrustServerCertificate=False;ApplicationIntent=ReadWrite;MultiSubnetFailover=False");

    protected override void OnModelCreating(ModelBuilder modelBuilder)
    {
        modelBuilder.Entity<Project>(entity =>
        {
            entity.HasKey(e => e.Id).HasName("PK_tbProject");

            entity.ToTable("Project");

            entity.Property(e => e.Id).HasColumnName("ID");
            entity.Property(e => e.CreatedDate).HasColumnType("datetime");
            entity.Property(e => e.EndDate).HasColumnType("datetime");
            entity.Property(e => e.ImagePath).HasMaxLength(200);
            entity.Property(e => e.ModifyDate).HasColumnType("datetime");
            entity.Property(e => e.ProjectManagerId).HasColumnName("ProjectManagerID");
            entity.Property(e => e.ProjectName).HasMaxLength(50);
            entity.Property(e => e.StartDate).HasColumnType("datetime");

            entity.HasOne(d => d.ProjectManager).WithMany(p => p.Projects)
                .HasForeignKey(d => d.ProjectManagerId)
                .HasConstraintName("FK_tbProject_tbUser");

            entity.HasOne(d => d.ProjectStatusNavigation).WithMany(p => p.Projects)
                .HasForeignKey(d => d.ProjectStatus)
                .HasConstraintName("FK_tbProject_tbProjectStatus");

            entity.HasOne(d => d.ProjectTypeNavigation).WithMany(p => p.Projects)
                .HasForeignKey(d => d.ProjectType)
                .HasConstraintName("FK_tbProject_tbProjectType");
        });

        modelBuilder.Entity<ProjectStatus>(entity =>
        {
            entity.HasKey(e => e.Id).HasName("PK_tbProjectStatus");

            entity.ToTable("ProjectStatus");

            entity.Property(e => e.Id).HasColumnName("ID");
            entity.Property(e => e.CreatedDate).HasColumnType("datetime");
            entity.Property(e => e.ModifyDate).HasColumnType("datetime");
            entity.Property(e => e.ProjectStatus1)
                .HasMaxLength(20)
                .HasColumnName("ProjectStatus");
            entity.Property(e => e.ProjectStatusCode).HasMaxLength(3);
        });

        modelBuilder.Entity<ProjectTeam>(entity =>
        {
            entity.HasKey(e => e.Id).HasName("PK_tbProjectTeam");

            entity.ToTable("ProjectTeam");

            entity.Property(e => e.Id).HasColumnName("ID");
            entity.Property(e => e.CreatedDate).HasColumnType("datetime");
            entity.Property(e => e.ModifyDate).HasColumnType("datetime");
            entity.Property(e => e.ProjectId).HasColumnName("ProjectID");
            entity.Property(e => e.UserId).HasColumnName("UserID");

            entity.HasOne(d => d.Project).WithMany(p => p.ProjectTeams)
                .HasForeignKey(d => d.ProjectId)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("FK_tbProjectTeam_tbProject");

            entity.HasOne(d => d.User).WithMany(p => p.ProjectTeams)
                .HasForeignKey(d => d.UserId)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("FK_tbProjectTeam_tbUser");
        });

        modelBuilder.Entity<ProjectType>(entity =>
        {
            entity.HasKey(e => e.Id).HasName("PK_tbProjectType");

            entity.ToTable("ProjectType");

            entity.Property(e => e.Id).HasColumnName("ID");
            entity.Property(e => e.CreatedDate).HasColumnType("datetime");
            entity.Property(e => e.ModifyDate).HasColumnType("datetime");
            entity.Property(e => e.ProjectType1)
                .HasMaxLength(50)
                .HasColumnName("ProjectType");
        });

        modelBuilder.Entity<Task>(entity =>
        {
            entity.HasKey(e => e.Id).HasName("PK_tbTask");

            entity.ToTable("Task");

            entity.Property(e => e.Id).HasColumnName("ID");
            entity.Property(e => e.CreatedDate).HasColumnType("datetime");
            entity.Property(e => e.ModifyDate).HasColumnType("datetime");
            entity.Property(e => e.ProjectId).HasColumnName("ProjectID");
            entity.Property(e => e.TaskDescription).HasMaxLength(500);
            entity.Property(e => e.TaskEndDate).HasColumnType("datetime");
            entity.Property(e => e.TaskParentId).HasColumnName("TaskParentID");
            entity.Property(e => e.TaskStartDate).HasColumnType("datetime");
            entity.Property(e => e.TaskSubject).HasMaxLength(50);
        });

        modelBuilder.Entity<TaskDetailView>(entity =>
        {
            entity
                .HasNoKey()
                .ToView("TaskDetailView");

            entity.Property(e => e.AssignTo).HasMaxLength(50);
            entity.Property(e => e.CreatedDate).HasColumnType("datetime");
            entity.Property(e => e.Id).HasColumnName("ID");
            entity.Property(e => e.ModifyDate).HasColumnType("datetime");
            entity.Property(e => e.ProjectId).HasColumnName("ProjectID");
            entity.Property(e => e.ProjectName).HasMaxLength(50);
            entity.Property(e => e.TaskDescription).HasMaxLength(500);
            entity.Property(e => e.TaskEndDate).HasColumnType("datetime");
            entity.Property(e => e.TaskParentId).HasColumnName("TaskParentID");
            entity.Property(e => e.TaskPriorityName).HasMaxLength(50);
            entity.Property(e => e.TaskStartDate).HasColumnType("datetime");
            entity.Property(e => e.TaskStatusName).HasMaxLength(50);
            entity.Property(e => e.TaskSubject).HasMaxLength(50);
        });

        modelBuilder.Entity<TaskPriority>(entity =>
        {
            entity.HasKey(e => e.Id).HasName("PK_tbTaskPriority");

            entity.ToTable("TaskPriority");

            entity.Property(e => e.Id).HasColumnName("ID");
            entity.Property(e => e.CreatedDate).HasColumnType("datetime");
            entity.Property(e => e.ModifyDate).HasColumnType("datetime");
            entity.Property(e => e.TaskPriority1)
                .HasMaxLength(50)
                .HasColumnName("TaskPriority");
        });

        modelBuilder.Entity<TaskStatus>(entity =>
        {
            entity.HasKey(e => e.Id).HasName("PK_tbTaskStatus");

            entity.ToTable("TaskStatus");

            entity.Property(e => e.Id).HasColumnName("ID");
            entity.Property(e => e.CreatedDate).HasColumnType("datetime");
            entity.Property(e => e.ModifyDate).HasColumnType("datetime");
            entity.Property(e => e.TaskStatus1)
                .HasMaxLength(50)
                .HasColumnName("TaskStatus");
            entity.Property(e => e.TaskStatusCode).HasMaxLength(3);
        });

        modelBuilder.Entity<ToDoList>(entity =>
        {
            entity.HasKey(e => e.Id).HasName("PK_tbToDoList");

            entity.ToTable("ToDoList");

            entity.Property(e => e.Id).HasColumnName("ID");
            entity.Property(e => e.CreatedDate).HasColumnType("datetime");
            entity.Property(e => e.ModifyDate).HasColumnType("datetime");
            entity.Property(e => e.TaskId).HasColumnName("TaskID");
            entity.Property(e => e.ToDoDescription).HasMaxLength(500);

            entity.HasOne(d => d.AssignedToNavigation).WithMany(p => p.ToDoLists)
                .HasForeignKey(d => d.AssignedTo)
                .HasConstraintName("FK_tbToDoList_tbUser");
        });

        modelBuilder.Entity<User>(entity =>
        {
            entity.HasKey(e => e.UserId).HasName("PK_tbUser");

            entity.ToTable("User");

            entity.Property(e => e.UserId)
                .ValueGeneratedNever()
                .HasColumnName("UserID");
            entity.Property(e => e.CreatedDate).HasColumnType("datetime");
            entity.Property(e => e.Email).HasMaxLength(50);
            entity.Property(e => e.FirstName).HasMaxLength(50);
            entity.Property(e => e.ImagePath).HasMaxLength(50);
            entity.Property(e => e.LastName).HasMaxLength(25);
            entity.Property(e => e.ModifyDate).HasColumnType("datetime");
            entity.Property(e => e.Password).HasMaxLength(20);
            entity.Property(e => e.UserName).HasMaxLength(20);
        });

        OnModelCreatingPartial(modelBuilder);
    }

    partial void OnModelCreatingPartial(ModelBuilder modelBuilder);
}
