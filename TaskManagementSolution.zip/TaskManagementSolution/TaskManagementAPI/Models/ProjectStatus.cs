﻿using System;
using System.Collections.Generic;

namespace TaskManagementAPI.Models;

public partial class ProjectStatus
{
    public int Id { get; set; }

    public string ProjectStatus1 { get; set; } = null!;

    public string ProjectStatusCode { get; set; } = null!;

    public bool IsDelete { get; set; }

    public bool IsActive { get; set; }

    public Guid? CreatedBy { get; set; }

    public Guid? ModifyBy { get; set; }

    public DateTime? CreatedDate { get; set; }

    public DateTime? ModifyDate { get; set; }

    public virtual ICollection<Project> Projects { get; } = new List<Project>();
}
