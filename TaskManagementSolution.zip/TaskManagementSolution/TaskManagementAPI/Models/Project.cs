﻿using System;
using System.Collections.Generic;

namespace TaskManagementAPI.Models;

public partial class Project
{
    public int Id { get; set; }

    public string? ProjectName { get; set; }

    public int? ProjectType { get; set; }

    public int? ProjectStatus { get; set; }

    public Guid? ProjectManagerId { get; set; }

    public DateTime? StartDate { get; set; }

    public DateTime? EndDate { get; set; }

    public string? ImagePath { get; set; }

    public Guid? CreatedBy { get; set; }

    public Guid? ModifyBy { get; set; }

    public DateTime? CreatedDate { get; set; }

    public DateTime? ModifyDate { get; set; }

    public virtual User? ProjectManager { get; set; }

    public virtual ProjectStatus? ProjectStatusNavigation { get; set; }

    public virtual ICollection<ProjectTeam> ProjectTeams { get; } = new List<ProjectTeam>();

    public virtual ProjectType? ProjectTypeNavigation { get; set; }
}
