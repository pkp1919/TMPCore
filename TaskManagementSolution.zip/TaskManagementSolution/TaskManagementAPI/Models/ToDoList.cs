﻿using System;
using System.Collections.Generic;

namespace TaskManagementAPI.Models;

public partial class ToDoList
{
    public int Id { get; set; }

    public int? TaskId { get; set; }

    public string? ToDoDescription { get; set; }

    public bool IsCompleted { get; set; }

    public Guid? AssignedTo { get; set; }

    public bool IsActive { get; set; }

    public bool IsDelete { get; set; }

    public Guid? CreatedBy { get; set; }

    public Guid? ModifyBy { get; set; }

    public DateTime? CreatedDate { get; set; }

    public DateTime? ModifyDate { get; set; }

    public virtual User? AssignedToNavigation { get; set; }
}
