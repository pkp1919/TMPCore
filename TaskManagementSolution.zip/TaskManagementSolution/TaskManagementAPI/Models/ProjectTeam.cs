﻿using System;
using System.Collections.Generic;

namespace TaskManagementAPI.Models;

public partial class ProjectTeam
{
    public int Id { get; set; }

    public int ProjectId { get; set; }

    public Guid UserId { get; set; }

    public bool IsActive { get; set; }

    public bool IsDelete { get; set; }

    public Guid? CreatedBy { get; set; }

    public Guid? ModifyBy { get; set; }

    public DateTime? CreatedDate { get; set; }

    public DateTime? ModifyDate { get; set; }

    public virtual Project Project { get; set; } = null!;

    public virtual User User { get; set; } = null!;
}
