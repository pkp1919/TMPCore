﻿namespace TaskManagementAPI.ViewModels
{
    public  class TaskViewModel
    {
        public string? ProjectName { get; set; }= null!;
        public string? TaskCreatedByName { get; set; } = null!;
        public string? TaskPriorityName  { get; set; } = null!;
        public string? TaskStatusName { get; set; } = null!;
    }
}
