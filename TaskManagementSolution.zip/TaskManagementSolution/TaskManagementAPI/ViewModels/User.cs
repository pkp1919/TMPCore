﻿using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;

namespace TaskManagementAPIs.Models;

public partial class User
{
   // public int modeType { get; set; }

    ////[Required(ErrorMessage = "Confirmation Password is required.")]
    //[Compare("Password", ErrorMessage = "Password and Confirmation Password must match.")]
    //public string ConfirmPassword { get; set; }
}

