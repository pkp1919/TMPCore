﻿using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.OpenApi.Models;
using TaskManagementAPI.Models;

namespace TaskManagementAPI.ViewModels
{
    public class ProjectView
    {
        public TaskManagementAPI.Models.Project prj { get; set; } = null;
        public List<SelectListItem> projectStatus { get; set; }
        public List<SelectListItem> projectType { get; set; }
        public List<SelectListItem> projectManager { get; set; }
        public IEnumerable<TaskManagementAPI.Models.ProjectStatus> projectStatusList { get; set; }
        public IFormFile ProjectImage { get; set; }

        public ProjectView InitializeDefaultData(TaskManagementContext context)
        {
            this.projectStatus = new ProjectStatusView().GetSelectList(context);
            this.projectType = new ProjectTypeView().GetSelectList(context);           
            this.projectManager = new UserView().GetSelectList(context).ToList();
            this.prj = new TaskManagementAPI.Models.Project();
            return this;
        }

        public List<Project> GetList(TaskManagementContext context)
        {
            var result = context.Projects.ToList();
            return result;
        }

        public List<SelectListItem> GetSelectList(TaskManagementContext context)
        {
            var result = context.Projects.ToList();
            List<SelectListItem> lstSelectList = new List<SelectListItem>();
            object Value, ID;
            foreach (var item in result)
            {
                Value = item.ProjectName;
                ID = item.Id;
                lstSelectList.Add(new SelectListItem()
                {
                    Text = Convert.ToString(Value),
                    Value = Convert.ToString(ID)
                });
            }
            lstSelectList.Insert(0, new SelectListItem { Text = "--Select--", Value = "", Selected = true });
            return lstSelectList;
        }

    }
}
