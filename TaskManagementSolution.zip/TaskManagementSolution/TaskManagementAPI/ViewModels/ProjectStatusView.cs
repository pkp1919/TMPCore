﻿using Microsoft.AspNetCore.Mvc.Rendering;
using TaskManagementAPI.Models;

namespace TaskManagementAPI.ViewModels
{
    public class ProjectStatusView
    {
        public List<TaskManagementAPI.Models.ProjectStatus> GetList(TaskManagementContext context)
        {
            var result = context.ProjectStatuses.ToList();
            return result;
        }


        public List<SelectListItem> GetSelectList(TaskManagementContext context)
        {
            var result = context.ProjectStatuses.ToList();
            List<SelectListItem> lstSelectList = new List<SelectListItem>();
            object Value, ID;
            foreach (var item in result)
            {
                Value = item.ProjectStatus1;
                ID = item.Id;
                lstSelectList.Add(new SelectListItem()
                {
                    Text = Convert.ToString(Value),
                    Value = Convert.ToString(ID)
                });
            }
            lstSelectList.Insert(0, new SelectListItem { Text = "--Select--", Value = "", Selected = true });
            return lstSelectList;
        }
    }
}
