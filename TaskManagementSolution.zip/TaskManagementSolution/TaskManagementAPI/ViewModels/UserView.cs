﻿using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.OpenApi.Models;
using TaskManagementAPI.Models;

namespace TaskManagementAPI.ViewModels
{
    public class UserView
    {
        public List<User> GetList(TaskManagementContext context)
        {
            var result = context.Users.ToList();
            return result;
        }


        public List<SelectListItem> GetSelectList(TaskManagementContext context)
        {
            var result = context.Users.ToList();
            List<SelectListItem> lstSelectList = new List<SelectListItem>();
            object Value, ID;
            foreach (var item in result)
            {
                Value = item.FirstName;
                ID = item.UserId;
                lstSelectList.Add(new SelectListItem()
                {
                    Text = Convert.ToString(Value),
                    Value = Convert.ToString(ID)
                });
            }
            lstSelectList.Insert(0, new SelectListItem { Text = "--Select--", Value = "", Selected = true });
            return lstSelectList;
        }

    }
}
