﻿using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.OpenApi.Models;
using TaskManagementAPI.Models;

namespace TaskManagementAPI.ViewModels
{
    public class TaskView
    {
       // private readonly TaskManagementContext dbcontext=null;
        public TaskManagementAPI.Models.Task task { get; set; }
        public List<SelectListItem> taskPriorityList { get; set; }
        public List<SelectListItem> taskStatusList { get; set; }
        public List<SelectListItem> projectList { get; set; }
        public List<SelectListItem> userList { get; set; }

        public TaskView InitializeDefaultData(TaskManagementContext context)
        {
            this.taskPriorityList = new TaskPrioritieView().GetSelectList(context);
            this.taskStatusList=new TaskStatusView().GetSelectList(context);
            this.projectList = new ProjectView().GetSelectList(context);
            this.userList= new UserView().GetSelectList(context).ToList();
            this.task = new TaskManagementAPI.Models.Task();
            return this;
        }



        //public TaskView(TaskManagementContext _dbcontext)
        //{
        //    dbcontext = _dbcontext;
        //    var result = dbcontext.TaskPriorities.ToList();
        //    List<SelectListItem> lstSelectList = new List<SelectListItem>();
        //    object Value, ID;
        //    foreach (var item in result)
        //    {
        //        Value = item.TaskPriority1;
        //        ID = item.Id;
        //        lstSelectList.Add(new SelectListItem()
        //        {
        //            Text = Convert.ToString(Value),
        //            Value = Convert.ToString(ID)
        //        });
        //    }
        //    lstSelectList.Insert(0, new SelectListItem { Text = "--Select--", Value = "0", Selected = true });
        //    taskPriorityList = lstSelectList;

        //    var result2 = dbcontext.TaskStatuses.ToList();
        //    List<SelectListItem> lstSelectList2 = new List<SelectListItem>();
        //    object Value2, ID2;
        //    foreach (var item in result)
        //    {
        //        Value2 = item.TaskPriority1;
        //        ID2 = item.Id;
        //        lstSelectList.Add(new SelectListItem()
        //        {
        //            Text = Convert.ToString(Value2),
        //            Value = Convert.ToString(ID2)
        //        });
        //    }
        //    lstSelectList.Insert(0, new SelectListItem { Text = "--Select--", Value = "0", Selected = true });

        //}
        //public TaskView()
        //{

        //}

    }
}
