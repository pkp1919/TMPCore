﻿using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.OpenApi.Models;
using System.Threading.Tasks;
using TaskManagementAPI.Models;

namespace TaskManagementAPI.ViewModels
{
    public class TaskStatusView
    {
        public List<TaskManagementAPI.Models.TaskStatus> GetList(TaskManagementContext context)
        {
            var result = context.TaskStatuses.ToList();
            return result;
        }


        public List<SelectListItem> GetSelectList(TaskManagementContext context)
        {
            var result = context.TaskStatuses.ToList();
            List<SelectListItem> lstSelectList = new List<SelectListItem>();
            object Value, ID;
            foreach (var item in result)
            {
                Value = item.TaskStatus1;
                ID = item.Id;
                lstSelectList.Add(new SelectListItem()
                {
                    Text = Convert.ToString(Value),
                    Value = Convert.ToString(ID)
                });
            }
            lstSelectList.Insert(0, new SelectListItem { Text = "--Select--", Value = "", Selected = true });
            return lstSelectList;
        }

    }
}
