﻿using Microsoft.AspNetCore.Mvc.Rendering;

namespace TaskManagementAPIs.Models
{
    public partial class Project
    {

        //public List<SelectListItem> projectType { get; set; }



    }
}
