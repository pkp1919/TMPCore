﻿using Microsoft.AspNetCore.Mvc;
using TaskManagementAPI.Repository;

namespace TaskManagementAPI.Controllers
{
    [ApiController]
    [Route("api/[Controller]")]
    public class TaskAPIController : ControllerBase
    {
        private readonly ITaskRepository _task;

        public TaskAPIController(ITaskRepository task)
        {
            _task = task ?? throw new ArgumentNullException(nameof(task));
        }

        //[HttpGet]
        //[Route("GetData")]
        //public async Task<IActionResult> Get()
        //{

        //    return Ok(await _task.GetData());
        //}

        [HttpGet]
        [Route("GetDataList")]
        public async Task<IActionResult> Get()
        {
            return Ok(await _task.GetDataList());
        }

        [HttpGet]
        [Route("GetDataByID/{Id}")]
        public async Task<IActionResult> GetDataById(int Id)
        {
            return Ok(await _task.GetDataByID(Id));
        }

        [HttpPost]
        [Route("AddUpdateData")]
        public async Task<IActionResult> Post(Models.Task model)
        {
            var result = await _task.InsertData(model);
            if (result.Id == 0)
            {
                return StatusCode(StatusCodes.Status500InternalServerError, "Something Went Wrong");
            }
            return Ok("Added Update Successfully");
        }

        [HttpPut]
        [Route("UpdateTaskStatus")]
        public async Task<IActionResult> Put(Models.Task status)
        {
            await _task.InsertData(status);
            return Ok("Updated Successfully");
        }

        [HttpDelete]
        //[HttpDelete("{id}")]
        [Route("DeleteData")]
        public JsonResult Delete(int id)
        {
            _task.DeleteData(id);
            return new JsonResult("Deleted Successfully");
        }
    }
}
