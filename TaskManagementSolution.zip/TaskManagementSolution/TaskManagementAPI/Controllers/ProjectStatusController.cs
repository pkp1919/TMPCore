﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore;
using TaskManagementAPI.Models;

namespace TaskManagementAPI.Controllers
{
    [ApiController]
    [Route("api/[Controller]")]
    public class ProjectStatusController : Controller
    {
        private readonly TaskManagementContext dbcontext;
        public ProjectStatusController(TaskManagementContext dbcontext)
        {
            this.dbcontext = dbcontext;
        }

        [HttpGet]
        public IActionResult GetProjectStatus()
        {
            var UserList = dbcontext.ProjectStatuses.ToList();
            return Ok(UserList);
        }

        [HttpGet]
        [Route("{Id:int}")]
        public async Task<IActionResult> GetUser([FromRoute] int Id)
        {
            ProjectStatus pjs = await dbcontext.ProjectStatuses.Where(i => i.Id == Id).FirstOrDefaultAsync();
            if (pjs != null)
                return Ok(pjs);
            else
                return NotFound();
        }

        [HttpPost]
        public async Task<IActionResult> AddProjectStatus(ProjectStatus model)
        {
            if (model.Id > 0)
            {
                model.ModifyDate = DateTime.Now;
                dbcontext.Entry(model).State = EntityState.Modified;
                await dbcontext.SaveChangesAsync();
            }
            else
            {
                model.Id = 0;
                model.CreatedDate = model.ModifyDate = DateTime.Now;
                await dbcontext.ProjectStatuses.AddAsync(model);
                await dbcontext.SaveChangesAsync();
            }

            return Ok(model);
        }

        [HttpPut]
        public async Task<IActionResult> UpdateProjectStatus(ProjectStatus model)
        {
            model.ModifyDate = DateTime.Now;
            dbcontext.Entry(model).State = EntityState.Modified;
            await dbcontext.SaveChangesAsync();
            return Ok(model);
        }

        [HttpGet("CheckProjectStatusCode/{ID}/{CompareValue}/{CompareWith}")]
        public async Task<IActionResult> CheckCode(int ID, string CompareValue, int CompareWith)
        {
            ProjectStatus pjs = null;
            if (CompareWith == 1)
                pjs = await dbcontext.ProjectStatuses.Where(i => i.ProjectStatusCode == CompareValue && i.Id != ID).FirstOrDefaultAsync();
            else
                pjs = await dbcontext.ProjectStatuses.Where(i => i.ProjectStatus1 == CompareValue && i.Id != ID).FirstOrDefaultAsync();

            if (pjs != null)
                return Ok();
            else
                return NotFound();
        }


        //public List<SelectListItem> GetProjectStatusList()
        //{   
        //        var result = dbcontext.ProjectStatuses.ToList();
        //        List<SelectListItem> lstSelectList = new List<SelectListItem>();
        //        object Value, ID;
        //        foreach (var item in result)
        //        {
        //            Value = item.ProjectStatus1;
        //            ID = item.Id;
        //            lstSelectList.Add(new SelectListItem()
        //            {
        //                Text = Convert.ToString(Value),
        //                Value = Convert.ToString(ID)
        //            });
        //        }

        //        lstSelectList.Insert(0, new SelectListItem { Text = "--Select--", Value = "", Selected = true });
        //        return lstSelectList;
                
            
        //}


    }
}
