﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Diagnostics;
using Microsoft.AspNetCore.Mvc;

namespace TaskManagementAPI.Controllers
{
    [ApiController]
    [Route("api/[Controller]")]
    public class ErrorController : Controller
    {
        [Route("Error/")]
        [AllowAnonymous]
        public IActionResult Error()
        {
           // var exceptionDetail = HttpContent.Features.Get<IExceptionHandlerPathFeature>();
            return Ok();
        }
    }
}
