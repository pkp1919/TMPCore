﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using System;
using System.Threading.Tasks;
using TaskManagementAPI.Repository;

namespace TaskManagementAPI.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class TaskStatusAPIController : Controller
    {
        private readonly ITaskStatusRepository _taskStatus;

        public TaskStatusAPIController(ITaskStatusRepository taskStatus)
        {
            _taskStatus = taskStatus ?? throw new ArgumentNullException(nameof(taskStatus));
        }

        [HttpGet]
        [Route("GetTaskStatus")]
        public async Task<IActionResult> Get()
        {
            return Ok(await _taskStatus.GetTaskStatus());
        }

        [HttpGet]
        [Route("GetTaskStatusByID/{Id}")]
        public async Task<IActionResult> GetDeptById(int Id)
        {
            return Ok(await _taskStatus.GetTaskStatusByID(Id));
        }


        [HttpPost]
        [Route("AddTaskStatus")]
        public async Task<IActionResult> Post(Models.TaskStatus model)
        {
            var result = await _taskStatus.InsertTaskStatus(model);
            if (result.Id == 0)
            {
                return StatusCode(StatusCodes.Status500InternalServerError, "Something Went Wrong");
            }

            return Ok("Added Update Successfully");
        }

        [HttpPut]
        [Route("UpdateTaskStatus")]
        public async Task<IActionResult> Put(Models.TaskStatus status)
        {
            await _taskStatus.InsertTaskStatus(status);
            return Ok("Updated Successfully");
        }


        [HttpDelete]
        //[HttpDelete("{id}")]
        [Route("DeleteTaskStatus")]
        public JsonResult Delete(int id)
        {
            _taskStatus.DeleteTaskStatus(id);
            return new JsonResult("Deleted Successfully");
        }

    }
}
