﻿using Microsoft.AspNetCore.Mvc;
using TaskManagementAPI.Repository;

namespace TaskManagementAPI.Controllers
{

    [ApiController]
    [Route("api/[Controller]")]
    public class ProjectAPIController : ControllerBase
    {
        private readonly IProjectRepository _project;

        public ProjectAPIController(IProjectRepository project)
        {
            _project = project ?? throw new ArgumentNullException(nameof(project));
        }      

        [HttpGet]
        [Route("GetDataList")]
        public async Task<IActionResult> Get()
        {
            return Ok(await _project.GetDataList());
        }

        [HttpGet]
        [Route("GetDataByID/{Id}")]
        public async Task<IActionResult> GetDataById(int Id)
        {
            return Ok(await _project.GetDataByID(Id));
        }

        [HttpPost]
        [Route("AddUpdateData")]
        public async Task<IActionResult> Post(Models.Project model)
        {
            var result = await _project.InsertData(model);
            if (result.Id == 0)
            {
                return StatusCode(StatusCodes.Status500InternalServerError, "Something Went Wrong");
            }
            return Ok("Added Update Successfully");
        }

        [HttpPut]
        [Route("UpdateTaskStatus")]
        public async Task<IActionResult> Put(Models.Project status)
        {
            await _project.InsertData(status);
            return Ok("Updated Successfully");
        }

        [HttpDelete]
        //[HttpDelete("{id}")]
        [Route("DeleteData")]
        public JsonResult Delete(int id)
        {
            _project.DeleteData(id);
            return new JsonResult("Deleted Successfully");
        }
    }
}
