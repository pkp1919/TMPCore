﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using TaskManagementAPI.Models;

namespace TaskManagementAPIs.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    public class LoginController : Controller
    {
        private readonly TaskManagementContext dbcontext;

        public LoginController(TaskManagementContext dbcontext)
        {
            this.dbcontext = dbcontext;
        }

        [HttpGet]
        public IActionResult GetUser()
        {
            var UserList = dbcontext.Users.ToList();
            return Ok(UserList);
        }

        [HttpGet]
        [Route("{Id:Guid}")]
        public async Task<IActionResult> GetUser([FromRoute]Guid Id)
        {
            string UserName = "pkp1919"; 
            string Password = "pass#123";
            User cat = await dbcontext.Users.Where(i => i.UserId == Id).FirstOrDefaultAsync();
            if (cat != null)
                return Ok(cat);
            else
                return NotFound();
        }

        [HttpGet("{UserName}/{Password}")]
        public async Task<IActionResult> GetUser(string UserName,  string Password)
        {
            //string UserName = "pkp1919";
            //string Password = "pass#123";
            User cat = await dbcontext.Users.Where(i => i.UserName == UserName && i.Password==Password).FirstOrDefaultAsync();
            if (cat != null)
                return Ok(cat);
            else
                return NotFound();
        }

        [HttpGet("CheckUserName/{UserName}/{UserID}")]
        public async Task<IActionResult> CheckUserName(string UserName, Guid UserID)
        {
            //string UserName = "pkp1919";
            //string Password = "pass#123";
            User cat = await dbcontext.Users.Where(i => i.UserName == UserName && i.UserId != UserID).FirstOrDefaultAsync();
            if (cat != null)
                return Ok();
            else
                return NotFound();
        }

        [HttpPost]
        public async Task<IActionResult> AddUser(User model)
        {            
            Guid newID = Guid.NewGuid();
            model.UserId = newID;            
            await dbcontext.Users.AddAsync(model);
            await dbcontext.SaveChangesAsync();
            return Ok(model);
        }
        [HttpPut]
        public async Task<IActionResult> UpdateUser(User model)
        {
            //Guid newID = new Guid();
            //model.UserId = newID;
            dbcontext.Entry(model).State = EntityState.Modified;
            //User cat = new User
            //{
            //    UserName = model.UserName,
            //    Password = model.Password,
            //    Email=model.Email
            //    CreatedDate = DateTime.Now
            //};


            await dbcontext.SaveChangesAsync();
            return Ok(model);
        }
        //public bool DeleteUser(Guid ID)
        //{
        //    bool result = false;
        //    var department = dbcontext.Users.Find(ID);
        //    if (department != null)
        //    {
        //        dbcontext.Entry(department).State = EntityState.Deleted;
        //        dbcontext.SaveChanges();
        //        result = true;
        //    }
        //    else
        //    {
        //        result = false;
        //    }
        //    return result;
        //}

    }
    }
