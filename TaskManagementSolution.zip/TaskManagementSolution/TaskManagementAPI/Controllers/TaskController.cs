﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using TaskManagementAPI.Models;

namespace TaskManagementAPI.Controllers
{
    [ApiController]
    [Route("api/[Controller]")]
    public class TaskController : Controller
    {
        private readonly TaskManagementContext dbcontext;
        public TaskController(TaskManagementContext dbcontext)
        {
            this.dbcontext = dbcontext;
        }

        [HttpGet]
        public IActionResult GetTask()
        {
            // var TaskList = dbcontext.Tasks.ToList();

            var TaskList = dbcontext.TaskDetailViews.AsEnumerable().ToList();
            return Ok(TaskList);
        }

        [HttpGet]
        [Route("{Id:int}")]
        public async Task<IActionResult> GetTask([FromRoute] int Id)
        {
            try { 
            TaskManagementAPI.ViewModels.TaskView pjs = new TaskManagementAPI.ViewModels.TaskView();
            pjs = new TaskManagementAPI.ViewModels.TaskView().InitializeDefaultData(dbcontext);
            pjs.task = await dbcontext.Tasks.Where(i => i.Id == Id).FirstOrDefaultAsync();
            if (pjs != null)
                return Ok(pjs);
            else
                return NotFound();
            }
            catch (Exception ex) {

                string exxx = ex.InnerException.ToString();
                return NotFound();
            }

        }

        [HttpPost]
        public async Task<IActionResult> AddTask(TaskManagementAPI.Models.Task model)
        {
            if (model.Id > 0)
            {
                model.ModifyDate = DateTime.Now;
                dbcontext.Entry(model).State = EntityState.Modified;
                await dbcontext.SaveChangesAsync();
            }
            else
            {
              //  model.Id = 0;
                model.CreatedDate = model.ModifyDate = DateTime.Now;
                await dbcontext.Tasks.AddAsync(model);
                await dbcontext.SaveChangesAsync();
            }

            return Ok(model);
        }

        [HttpPut]
        public async Task<IActionResult> UpdateProject(TaskManagementAPI.Models.Task model)
        {
            model.ModifyDate = DateTime.Now;
            dbcontext.Entry(model).State = EntityState.Modified;
            await dbcontext.SaveChangesAsync();
            return Ok(model);
        }

    }
}
