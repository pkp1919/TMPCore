﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using TaskManagementAPI.Models;

namespace TaskManagementAPI.Controllers
{
    [ApiController]
    [Route("api/[Controller]")]
    public class TaskPriorityController : Controller
    {
        private readonly TaskManagementContext dbcontext;
        public TaskPriorityController(TaskManagementContext dbcontext)
        {
            this.dbcontext = dbcontext;
        }


        [HttpGet]
        public IActionResult GetProjectStatus()
        {
            var UserList = dbcontext.TaskPriorities.ToList();
            return Ok(UserList);
        }

        [HttpGet]
        [Route("{Id:int}")]
        public async Task<IActionResult> Get([FromRoute] int Id)
        {
            TaskPriority pjs = await dbcontext.TaskPriorities.Where(i => i.Id == Id).FirstOrDefaultAsync();
            if (pjs != null)
                return Ok(pjs);
            else
                return NotFound();
        }

        [HttpPost]
        public async Task<IActionResult> AddTaskStatus(TaskPriority model)
        {
            if (model.Id > 0)
            {
                model.ModifyDate = DateTime.Now;
                dbcontext.Entry(model).State = EntityState.Modified;
                await dbcontext.SaveChangesAsync();
            }
            else
            {
                model.Id = 0;
                model.CreatedDate = model.ModifyDate = DateTime.Now;
                await dbcontext.TaskPriorities.AddAsync(model);
                await dbcontext.SaveChangesAsync();
            }

            return Ok(model);
        }

        [HttpPut]
        public async Task<IActionResult> UpdateProjectStatus(TaskPriority model)
        {
            model.ModifyDate = DateTime.Now;
            dbcontext.Entry(model).State = EntityState.Modified;
            await dbcontext.SaveChangesAsync();
            return Ok(model);
        }

        [HttpGet("CheckTaskPriorityName/{ID}/{TaskPriority}")]
        public async Task<IActionResult> CheckCode(int ID, string TaskPriority)
        {
            TaskPriority tp = null;
           
                tp = await dbcontext.TaskPriorities.Where(i => i.TaskPriority1 == TaskPriority && i.Id != ID).FirstOrDefaultAsync();
            
            if (tp != null)
                return Ok();
            else
                return NotFound();
        }

    }
}
