﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore;
using TaskManagementAPI.Models;

namespace TaskManagementAPI.Controllers
{
    [ApiController]
    [Route("api/[Controller]")]
    public class ProjectController : Controller
    {
        private readonly TaskManagementContext dbcontext;
        public ProjectController(TaskManagementContext dbcontext)
        {
            this.dbcontext = dbcontext;
        }


        [HttpGet]
        public IActionResult GetProjectStatus()
        {
            var UserList = dbcontext.Projects.ToList();
            return Ok(UserList);
        }

        [HttpGet]
        [Route("{Id:int}")]
        public async Task<IActionResult> GetUser([FromRoute] int Id)
        {
            Project pjs = await dbcontext.Projects.Where(i => i.Id == Id).FirstOrDefaultAsync();
            if (pjs != null)
                return Ok(pjs);
            else
                return NotFound();
        }

        [HttpPost]
        public async Task<IActionResult> AddProject(Project model)
        {
            if (model.Id > 0)
            {
                model.ModifyDate = DateTime.Now;
                dbcontext.Entry(model).State = EntityState.Modified;
                await dbcontext.SaveChangesAsync();
            }
            else
            {
                model.Id = 0;
                model.CreatedDate = model.ModifyDate = DateTime.Now;
                await dbcontext.Projects.AddAsync(model);
                await dbcontext.SaveChangesAsync();
            }

            return Ok(model);
        }

        [HttpPut]
        public async Task<IActionResult> UpdateProject(Project model)
        {
            model.ModifyDate = DateTime.Now;
            dbcontext.Entry(model).State = EntityState.Modified;
            await dbcontext.SaveChangesAsync();
            return Ok(model);
        }

        //public List<SelectListItem> GetProjectList()
        //{
        //    var result = dbcontext.Projects.ToList();
        //    List<SelectListItem> lstSelectList = new List<SelectListItem>();
        //    object Value, ID;
        //    foreach (var item in result)
        //    {
        //        Value = item.ProjectName;
        //        ID = item.Id;
        //        lstSelectList.Add(new SelectListItem()
        //        {
        //            Text = Convert.ToString(Value),
        //            Value = Convert.ToString(ID)
        //        });
        //    }

        //    lstSelectList.Insert(0, new SelectListItem { Text = "--Select--", Value = "", Selected = true });
        //    return lstSelectList;


        //}

    }
}
