﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using TaskManagementAPI.Models;

namespace TaskManagementAPI.Controllers
{
    [ApiController]
    [Route("api/[Controller]")]
    public class TaskStatusController : Controller
    {
        private readonly TaskManagementContext dbcontext;
        public TaskStatusController(TaskManagementContext dbcontext)
        {
            this.dbcontext = dbcontext;
        }


        [HttpGet]
        public IActionResult GetProjectStatus()
        {
            var UserList = dbcontext.TaskStatuses.ToList();
            return Ok(UserList);
        }

        [HttpGet]
        [Route("{Id:int}")]
        public async Task<IActionResult> Get([FromRoute] int Id)
        {
            TaskManagementAPI.Models.TaskStatus pjs = await dbcontext.TaskStatuses.Where(i => i.Id == Id).FirstOrDefaultAsync();
            if (pjs != null)
                return Ok(pjs);
            else
                return NotFound();
        }

        [HttpPost]
        public async Task<IActionResult> AddTaskStatus(TaskManagementAPI.Models.TaskStatus model)
        {
            if (model.Id > 0)
            {
                model.ModifyDate = DateTime.Now;
                dbcontext.Entry(model).State = EntityState.Modified;
                await dbcontext.SaveChangesAsync();
            }
            else
            {
                model.Id = 0;
                model.CreatedDate = model.ModifyDate = DateTime.Now;
                await dbcontext.TaskStatuses.AddAsync(model);
                await dbcontext.SaveChangesAsync();
            }

            return Ok(model);
        }

        [HttpPut]
        public async Task<IActionResult> UpdateProjectStatus(TaskManagementAPI.Models.TaskStatus model)
        {
            model.ModifyDate = DateTime.Now;
            dbcontext.Entry(model).State = EntityState.Modified;
            await dbcontext.SaveChangesAsync();
            return Ok(model);
        }

        [HttpGet("CheckTaskStatusCode/{ID}/{CompareValue}/{CompareWith}")]
        public async Task<IActionResult> CheckCode(int ID, string CompareValue, int CompareWith)
        {
            TaskManagementAPI.Models.TaskStatus pjs = null;
            if (CompareWith == 1)
                pjs = await dbcontext.TaskStatuses.Where(i => i.TaskStatusCode == CompareValue && i.Id != ID).FirstOrDefaultAsync();
            else
                pjs = await dbcontext.TaskStatuses.Where(i => i.TaskStatusCode == CompareValue && i.Id != ID).FirstOrDefaultAsync();

            if (pjs != null)
                return Ok();
            else
                return NotFound();
        }


    }
}
