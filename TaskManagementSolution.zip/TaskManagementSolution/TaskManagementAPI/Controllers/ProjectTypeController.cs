﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using TaskManagementAPI.Models;

namespace TaskManagementAPI.Controllers
{
    [ApiController]
    [Route("api/[Controller]")]
    public class ProjectTypeController : Controller
    {
        private readonly TaskManagementContext dbcontext;
        public ProjectTypeController(TaskManagementContext dbcontext)
        {
            this.dbcontext = dbcontext;
        }

        [HttpGet]
        public IActionResult GetProjectStatus()
        {
            var UserList = dbcontext.ProjectTypes.ToList();
            return Ok(UserList);
        }

        [HttpGet]
        [Route("{Id:int}")]
        public async Task<IActionResult> Get([FromRoute] int Id)
        {
            ProjectType pjs = await dbcontext.ProjectTypes.Where(i => i.Id == Id).FirstOrDefaultAsync();
            if (pjs != null)
                return Ok(pjs);
            else
                return NotFound();
        }

        [HttpPost]
        public async Task<IActionResult> AddTaskStatus(ProjectType model)
        {
            if (model.Id > 0)
            {
                model.ModifyDate = DateTime.Now;
                dbcontext.Entry(model).State = EntityState.Modified;
                await dbcontext.SaveChangesAsync();
            }
            else
            {
                model.Id = 0;
                model.CreatedDate = model.ModifyDate = DateTime.Now;
                await dbcontext.ProjectTypes.AddAsync(model);
                await dbcontext.SaveChangesAsync();
            }

            return Ok(model);
        }

        [HttpPut]
        public async Task<IActionResult> UpdateProjectStatus(ProjectType model)
        {
            model.ModifyDate = DateTime.Now;
            dbcontext.Entry(model).State = EntityState.Modified;
            await dbcontext.SaveChangesAsync();
            return Ok(model);
        }

        [HttpGet("CheckTaskPriorityName/{ID}/{ProjectTypeName}")]
        public async Task<IActionResult> CheckCode(int ID, string ProjectTypeName)
        {
            ProjectType pjs = null;
            pjs = await dbcontext.ProjectTypes.Where(i => i.ProjectType1 == ProjectTypeName && i.Id != ID).FirstOrDefaultAsync();

            if (pjs != null)
                return Ok();
            else
                return NotFound();
        }
    }
}
